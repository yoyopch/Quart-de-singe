int main() {
  Partie p;
  char joueurs[MAX_CHAR] = "hhhh";
  // on teste avec une partie de 4 humains
  init(p, joueurs);

  //V�rification des param�tres de la partie et des fonctions utiles au bon d�roulement de la partie

  assert(p.nbJoueurs == strlen(joueurs));
  assert(p.taillemot == 0);
  assert(p.nouveauTour == FAUX);
  assert(p.dernierJoueurPerdant == -1);

  for (unsigned int i = 0; i < p.nbJoueurs; i++) {
    assert(p.score[i] == 0.);
    assert(p.ordre[i] == toupper(joueurs[i]));
  }
  int valeur3 = ajoutLettre(p, '!');
  assert(valeur3 == 2);
  valeur3 = ajoutLettre(p, '?');
  assert(valeur3 == 1);

  for (int i = 0; i < MAX_LENMOT; i++) {
    ajoutLettre(p, 'A' + i);
  }
  for (unsigned int i = 0; i < MAX_LENMOT; i++) {
    assert(p.mot[i] == 'A' + i);
  }
  unsigned int valeur1 = verifMot(p, "test");
  assert(valeur1 == 1);

  for (unsigned int i = 0; i < 4; i++) {
    p.score[1] += 0.25;
  }
  unsigned int valeur2 = finduJeu(p);
  assert(valeur2 = 1);

  strcpy(p.motJoueurDeviner, "test");
  resetMotJoueur(p);
  for (unsigned int i = 0; i < MAX_LENMOT; i++) {
    assert(p.motJoueurDeviner[i] == CHAINE_VIDE);
  }

  detruireJeu(p);
  assert(p.ordre == NULL);
  assert(p.score == NULL);
}
