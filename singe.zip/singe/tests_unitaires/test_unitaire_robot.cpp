int main() {
  char joueurs[MAX_CHAR] = "rrr";
  //on teste la partie avec 3 robots

  //Initialisation d�un dictionnaire et d�une partie pour tester les fonction utiles aux robots
  Partie p;
  Dico dico;
  remplirDico(dico, "test_Dico.txt");

  init(p, joueurs);

  ajoutLettreRobot(p, 'A');
  assert(p.taillemot == 1);
  assert(strcmp(p.mot, "A") == 0);
  assert(p.motRobot[0] == CHAINE_VIDE);

  int indexMot = 0;
  unsigned int valeur1 = ChercherMotDico_Robot(dico, p, indexMot);
  assert(valeur1 == 0);
  assert(indexMot == 0);

  char* listeLettre = new char[MAX_CHAR];
  resetListeLettre(listeLettre);

  for (unsigned int i = 0; i < MAX_CHAR; i++) {
    assert(listeLettre[i] == CHAINE_VIDE);
  }

  unsigned int valeur3 = VerifLettreUtil('A', listeLettre);
  assert(valeur3 == 0);

  unsigned int valeur2 = AjoutLettreUtil('A', listeLettre);
  valeur3 = VerifLettreUtil('A', listeLettre);
  assert(valeur2 == 0);
  assert(valeur3 == 1);

  valeur2 = AjoutLettreUtil('A', listeLettre);
  assert(valeur2 == 1);
  assert(valeur3 == 1);
}
