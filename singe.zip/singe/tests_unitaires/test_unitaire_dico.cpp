int main() {
  //Cr�ation du dictionnaire
  Dico dico;
  remplirDico(dico, "test_Dico.txt");

  //V�rification du remplissage du dictionnaire 
  // (qui contient des sauts de ligne, tabulation, ou espaces entre les mots
  // et des mots en minuscules et majuscules)   
  assert(dico.tailleDico == 5);
  assert(strcmp(dico.mots[0], "AUREVOIR") == 0);
  assert(strcmp(dico.mots[1], "BONJOUR") == 0);
  assert(strcmp(dico.mots[2], "HELLO") == 0);
  assert(strcmp(dico.mots[3], "WORD") == 0);
  assert(strcmp(dico.mots[4], "ZOO") == 0);
  char mot[MAX_CHAR] = "Bonjour";
  unsigned int valeur = trouverMotDansDico(dico, mot);
  assert(valeur == 1);

  desallouerDico(dico);
  assert(dico.mots == NULL);
}
