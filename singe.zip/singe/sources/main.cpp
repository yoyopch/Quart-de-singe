#include <iostream>
#include <cassert>

#include "header.h"
#include "dico.h"
#include "partie.h"
#include "robot.h"

#pragma warning(disable:4996)

/**
 * @file main.cpp
 * @author Yohann PECH - Mehdi BOUZIANE - Grp 106
 * @brief fichier source.
 */

int main(int argc, char* argv[]) {

  srand((unsigned int)time(NULL));

  char* argument = argv[1];
  if (strcmp(argument, "test_partie") == 0) {
    Partie p;
    char joueurs[MAX_CHAR] = "hhhh";
    init(p, joueurs);

    //Verification des param�tres de la partie 

    assert(p.nbJoueurs == strlen(joueurs));
    assert(p.taillemot == 0);
    assert(p.nouveauTour == FAUX);
    assert(p.dernierJoueurPerdant == -1);

    for (unsigned int i = 0; i < p.nbJoueurs; i++) {
      assert(p.score[i] == 0.);
      assert(p.ordre[i] == toupper(joueurs[i]));
    }
    int valeur3 = ajoutLettre(p, '!');
    assert(valeur3 == 2);
    valeur3 = ajoutLettre(p, '?');
    assert(valeur3 == 1);

    for (int i = 0; i < MAX_LENMOT; i++) {
      ajoutLettre(p, 'A' + i);
    }
    for (unsigned int i = 0; i < MAX_LENMOT; i++) {
      assert(p.mot[i] == 'A' + i);
    }
    unsigned int valeur1 = verifMot(p, "test");
    assert(valeur1 == 1);

    for (unsigned int i = 0; i < 4; i++) {
      p.score[1] += 0.25;
    }
    unsigned int valeur2 = finduJeu(p);
    assert(valeur2 = 1);

    strcpy(p.motJoueurDeviner, "test");
    resetMotJoueur(p);
    for (unsigned int i = 0; i < MAX_LENMOT; i++) {
      assert(p.motJoueurDeviner[i] == CHAINE_VIDE);
    }


    detruireJeu(p);
    assert(p.ordre == NULL);
    assert(p.score == NULL);
  }
  else if (strcmp(argument, "test_Dico") == 0) {

    Dico dico;
    remplirDico(dico, "test_Dico.txt");

    //Verification du remplissage du dictionnaire 
    // ( qui contient des sauts de ligne, tabulation, ou espaces entre les mots)
    // et des mots en minuscules et majuscules   
    assert(dico.tailleDico == 5);
    assert(strcmp(dico.mots[0], "AUREVOIR") == 0);
    assert(strcmp(dico.mots[1], "BONJOUR") == 0);
    assert(strcmp(dico.mots[2], "HELLO") == 0);
    assert(strcmp(dico.mots[3], "WORD") == 0);
    assert(strcmp(dico.mots[4], "ZOO") == 0);
    char mot[MAX_CHAR] = "Bonjour";
    unsigned int valeur = trouverMotDansDico(dico, mot);
    assert(valeur == 1);

    desallouerDico(dico);
    assert(dico.mots == NULL);

  }
  else if (strcmp(argument, "test_robot") == 0) {

    char joueurs[MAX_CHAR] = "rrr";
    Partie p;
    Dico dico;
    remplirDico(dico, "test_Dico.txt");

    init(p, joueurs);

    ajoutLettreRobot(p, 'A');
    assert(p.taillemot == 1);
    assert(strcmp(p.mot, "A") == 0);
    assert(p.motRobot[0] == CHAINE_VIDE);

    int indexMot = 0;
    unsigned int valeur1 = ChercherMotDico_Robot(dico, p, indexMot);
    assert(valeur1 == 0);
    assert(indexMot == 0);

    char* listeLettre = new char[MAX_CHAR];
    resetListeLettre(listeLettre);

    for (unsigned int i = 0; i < MAX_CHAR; i++) {
      assert(listeLettre[i] == CHAINE_VIDE);
    }

    unsigned int valeur3 = VerifLettreUtil('A', listeLettre);
    assert(valeur3 == 0);

    unsigned int valeur2 = AjoutLettreUtil('A', listeLettre);
    valeur3 = VerifLettreUtil('A', listeLettre);
    assert(valeur2 == 0);
    assert(valeur3 == 1);

    valeur2 = AjoutLettreUtil('A', listeLettre);
    assert(valeur2 == 1);
    assert(valeur3 == 1);

  }
  else {
    Dico dico;
    Partie p;
    remplirDico(dico, NULL);

    init(p, argv[1]);
    mancheJeu(dico, p);
  }
}


int main() {

  char joueurs[MAX_CHAR] = "rrr";
  //on teste la partie avec 3 robots
  Partie p;
  Dico dico;
  remplirDico(dico, "test_Dico.txt");

  init(p, joueurs);

  ajoutLettreRobot(p, 'A');
  assert(p.taillemot == 1);
  assert(strcmp(p.mot, "A") == 0);
  assert(p.motRobot[0] == CHAINE_VIDE);

  int indexMot = 0;
  unsigned int valeur1 = ChercherMotDico_Robot(dico, p, indexMot);
  assert(valeur1 == 0);
  assert(indexMot == 0);

  char* listeLettre = new char[MAX_CHAR];
  resetListeLettre(listeLettre);

  for (unsigned int i = 0; i < MAX_CHAR; i++) {
    assert(listeLettre[i] == CHAINE_VIDE);
  }

  unsigned int valeur3 = VerifLettreUtil('A', listeLettre);
  assert(valeur3 == 0);

  unsigned int valeur2 = AjoutLettreUtil('A', listeLettre);
  valeur3 = VerifLettreUtil('A', listeLettre);
  assert(valeur2 == 0);
  assert(valeur3 == 1);

  valeur2 = AjoutLettreUtil('A', listeLettre);
  assert(valeur2 == 1);
  assert(valeur3 == 1);
}
